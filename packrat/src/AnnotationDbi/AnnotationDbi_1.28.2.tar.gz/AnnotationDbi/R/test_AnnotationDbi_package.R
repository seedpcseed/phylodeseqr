.test <- function() BiocGenerics:::testPackage("AnnotationDbi")
